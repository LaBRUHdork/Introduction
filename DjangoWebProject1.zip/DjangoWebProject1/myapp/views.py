from django.shortcuts import render
from django.http import HttpResponseRedirect
from . import forms
from . import models
# Create your views here.
def index(request):
    if request.method == 'POST':
            chc = models.PollModel.objects.get(choice_text=dt.cleaned_data['choice'])
            chc.votes += 1
            chc.save()
            return HttpResponseRedirect('/myapp/1/results')
    return render(request, 'index.html', { 'question': models.QuestionModel.objects.all()[0], 'choice': models.PollModel.objects.all()[0], 'choice2': models.PollModel.objects.all()[1]} )

def results(request):
    poll_data = models.PollModel.objects.all()
    return render(request, 'index1.html', { 'poll_data': poll_data })