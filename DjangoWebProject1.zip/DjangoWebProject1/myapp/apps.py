from django.apps import AppConfig


class myappConfig(AppConfig):
    name = 'myapp'
