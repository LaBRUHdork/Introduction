#!C:\Users\diwan\source\repos\DjangoWebProject1\ques-vs2022-env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
